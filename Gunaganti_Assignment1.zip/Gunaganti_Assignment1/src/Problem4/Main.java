package Problem4;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<String> a1=new ArrayList<>();
		System.out.println("Enter the number of Strings");
		int n=sc.nextInt();
		System.out.println("Enter the Strings");
		int i=0;
		while(i<n) {
			a1.add(sc.next());
			i++;
		}
		sc.close();
		
		acendString(a1);
		
	}
	public static void acendString(ArrayList<String> arrl) {
		
		//ListIterator<String> list=a1.listIterator();
		
		String t="";
		
		for(int c=0;c<arrl.size()-1;c++)
		{
			for(int d=1;d<arrl.size();d++)
			{
			if(arrl.get(c).length()>arrl.get(d).length())
			{
				
				t=arrl.get(c);
				arrl.set(c, arrl.get(d));
				arrl.set(d, t);
			}
			}
			
		}
		
		System.out.println("Ascending order : "+arrl);
		
	}

	}


