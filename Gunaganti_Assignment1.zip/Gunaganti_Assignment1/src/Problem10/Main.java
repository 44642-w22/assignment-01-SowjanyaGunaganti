package Problem10;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Deque<Character> d=new LinkedList<>();
		System.out.println("Enter the number of Characters : ");
		int p=sc.nextInt();
		System.out.println("Enter the Characters: ");
		int m=0;
		while(m<p)
		{
			d.addFirst(sc.next().charAt(0));
			m++;
		}
		System.out.println("Enter the number of BinaryNumbers ");
		int no=sc.nextInt();
		int a[]=new int[no];
		System.out.println("Enter the Binary Numbers");
		int q=0;
		while(q<no) {
			a[q]=sc.nextInt();
			q++;
		}
		sc.close();
		removeCh(d,a);

	}
	
	public static void removeCh(Deque<Character> d,int[] a) {
		
		char c = 0;
		String s="";
		
		for(int u=0;u<a.length;u++)
		{
			if(a[u]==1)
			{
				c=d.removeLast();
			}
			if(a[u]==0)
			{
				if(c!=0)
				{
				d.addLast(c);
				c=0;
				}
				
			}
		}
		
		int i=0;
		int size=d.size();
		while(i<size)
		{
			s+=d.removeLast();
			i++;
		
		}
		System.out.println(s);
	}
	}

	


