package Problem9;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Queue<Integer> q=new LinkedList<>();
		System.out.println("Enter the no of Elements for Queue :");
		int no=sc.nextInt();
		System.out.println("Enter the Elements");
		int h=0;
		while(h<no) {
			q.add(sc.nextInt());
			h++;
		}
		sc.close();
		combineEO(q);
	}
	
	public static void combineEO(Queue<Integer> q)
	{
		ArrayList<Integer> arr=new ArrayList<Integer>();
		ArrayList<Integer> arr1=new ArrayList<Integer>();
		ArrayList<Integer> arr2=new ArrayList<Integer>();
		ArrayList<Integer> arr3=new ArrayList<Integer>();
		
		
		
		Iterator<Integer> iter=q.iterator();
		
	
		int i=0;
		
		while(iter.hasNext())
		{
			 arr.add(iter.next());
		}
		
		for(i=arr.size()-1;i>=0;i--)
		{
			if(arr.get(i)%2!=0)
			{
				arr1.add(arr.get(i));
			}
			else {
				arr2.add(arr.get(i));
			}
			
		}
		
		
		int max = Math.max(arr2.size(), arr1.size());		
		
		for(int j=0;j<max;j++)
		{
			if(j<arr2.size())
			{
			arr3.add(arr2.get(j));
			}
			if(j<arr1.size())
			{
			arr3.add(arr1.get(j));
			}
			
		}
			
		System.out.println(arr3);
	}

	}


