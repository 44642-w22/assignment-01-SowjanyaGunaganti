package Problem5;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String: ");
		String s=sc.next();
		sc.close();
		balancedStr(s);
	}
	
	public static void balancedStr(String str) {
		
		
		Stack<Character> sta=new Stack<>();
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='[' || str.charAt(i)=='{'||str.charAt(i)=='(')
			{
				sta.push(str.charAt(i));
				
			}
			else if((str.charAt(i)==']' && sta.peek()=='[') || (str.charAt(i)=='}' && sta.peek()=='{')|| (str.charAt(i)==')' && sta.peek()=='('))
			{
				
					sta.pop();
			}
				else
				{
					sta.push(str.charAt(i));
				}
			}
		
		if(sta.isEmpty())
		{
			System.out.println("True");
		}
		else
		{
			System.out.print("False");
		}
		
		
	}

	}


