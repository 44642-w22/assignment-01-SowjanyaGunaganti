package Problem1;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		LinkedList<Integer> list1 = new LinkedList<Integer>();
		System.out.print("Enter Number of Elements:");
		int num=sc.nextInt();
		int si=0;
		System.out.println("Enter the Elements:");
		while(si<num)
		{
			list1.add(sc.nextInt());
			si++;
		}
		sc.close();
		System.out.println("The Perfect Numbers are "+Perfectnumber(list1));

	}
	public static LinkedList<Integer> Perfectnumber(LinkedList<Integer> l1) {
		LinkedList<Integer> l2 = new LinkedList<Integer>();
		ListIterator<Integer> ind = l1.listIterator();
		while (ind.hasNext()) {
			int j = 1;
			int n = ind.next();
			int s = 0;
			while (j != n) {
				if (n % j == 0) {
					s = s + j;
				}	
				j++;
			}
			if (s == n) {
				l2.add(n);
			}
		}
		return l2;
	}

}
