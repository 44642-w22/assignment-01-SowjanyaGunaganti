package Problem3;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc=new Scanner(System.in);
	ArrayList<Integer> a1=new ArrayList<>();
	System.out.println("Enter the number of elements in Arraylist");
	int n=sc.nextInt();
	System.out.println("Enter the elements");
	int k=0;
	while(k<n) {
		a1.add(sc.nextInt());
		k++;
	}
	sc.close();
	
	highestNumber(a1);
}

public static void highestNumber(ArrayList<Integer> a1)
{
	int max=Integer.MIN_VALUE;
	
	
	for(int i=0; i<a1.size();i++)
	{
		if(a1.get(i)>max)
		{
			max=a1.get(i);
		}
	}
	
	System.out.println("The Highest Integer is "+max);		
}

}
