package Problem8;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Queue<Integer> que=new LinkedList<>();
		System.out.println("Enter the no of Elements for Queue :");
		int no=sc.nextInt();
		System.out.println("Enter the Elements");
		int h=0;
		while(h<no) {
			que.add(sc.nextInt());
			h++;
		}
		sc.close();
		combineFirstLast(que);

	}
	
	public static void combineFirstLast(Queue<Integer> queue) {
		
		ArrayList<Integer> a=new ArrayList<Integer>();
		Stack<Integer> s=new Stack<>();
		
		Iterator<Integer> iter=queue.iterator();
		
		int rear=queue.size()-1;
		int i=0;
		
		while(iter.hasNext())
		{
			s.add(iter.next());
		}
		
		while(i<rear)
		{
			a.add(queue.poll());
			a.add(s.pop());
			i++;
			rear--;
		}
		if(i==rear)
		{
			a.add(queue.peek());
		}
		
		System.out.println(a);
	}

	}


