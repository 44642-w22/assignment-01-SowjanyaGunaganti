package Problem6;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Stack<Integer> s=new Stack<>();
		System.out.println("Enter a even integer :");
		int num1=sc.nextInt();
		if(num1%2==0)
		{
			System.out.println("Enter "+num1+" integers: ");
			int i=0;
			while(i<num1) {
				s.push(sc.nextInt());
				i++;
			}
		}
		else
		{
			System.out.println("Enter an even Integer");
		}
		sc.close();
		outputList(s);
	}
	
	public static void outputList(Stack<Integer> s) {
		
		ArrayList<Integer> al=new ArrayList<>();
		int slen=s.size();
		for(int i=slen-1; i>=slen/2;i--)
		{
		al.add(s.get(i));
		}
		for(int i=0; i<slen/2;i++)
		{
		al.add(s.get(i));
		}
		System.out.println(al);
		
		
	}

	}


