package Problem2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		////
		LinkedList<Integer> list1 = new LinkedList<Integer>();
		System.out.print("Enter Number of Elements:");
		int num=sc.nextInt();
		int i=0;
		System.out.println("Enter the elements");
		while(i<num)
		{
			list1.add(sc.nextInt());
			i++;
		}
		System.out.println("Enter the number k");
		int k=sc.nextInt();
		sc.close();
		
		System.out.println(cSum(list1, k));	
	}
	
public static LinkedList<ArrayList<Integer>> cSum(LinkedList<Integer> l1, int k){
		
		
		LinkedList<ArrayList<Integer>> l2= new LinkedList<ArrayList<Integer>>();
		ListIterator<Integer> ind = l1.listIterator();
		while(ind.hasNext()) {
			ArrayList<Integer> al=new ArrayList<Integer>(2);
			int n1=ind.next();
			if(l1.size()==ind.nextIndex())
			{
				break;
			}
			int nextIndex=ind.nextIndex();
			int n2=l1.get(nextIndex);
			int s=0;
			s=n1+n2;
			if(s==k)
			{
				al.add(n1);
				al.add(n2);
				l2.add(al);
			}
			
		}
		return l2;
	}

	}


