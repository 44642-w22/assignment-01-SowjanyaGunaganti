package Problem7;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Queue<Integer> q=new LinkedList<>();
		System.out.println("Enter the number of Binaryno :");
		int number=sc.nextInt();
		System.out.println("Enter the Binary Numbers");
		int j=0;
		while(j<number) {
			q.add(sc.nextInt());
			j++;
		}
		sc.close();
		covertDec(q);
	}
	
	public static void covertDec(Queue<Integer> queue) {
		
		//System.out.println(q);
		int num=0, i=0;
		while(!queue.isEmpty())
		{
			//System.out.println(q.peek());
			
			if(queue.peek()==0)
			{
				num=(int) (num+(Math.pow(2, i)*0))	;
				i++;
				queue.poll();
			}
			else if(queue.peek()==1)
			{
				num=(int) (num+(Math.pow(2, i)*1))	;
				i++;
				queue.poll();
			}
		}
		System.out.println(num);
		
		
		
		
	

	}

}
